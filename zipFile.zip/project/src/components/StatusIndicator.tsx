import type { ConnectionState } from '@/hooks/useRemoteBrowser';

interface StatusIndicatorProps {
  state: ConnectionState;
}

const STATE_CONFIG: Record<ConnectionState, { label: string; color: string; dot: string }> = {
  disconnected: { label: 'Disconnected', color: 'text-gray-400', dot: 'bg-gray-500' },
  connecting: { label: 'Connecting...', color: 'text-amber-400', dot: 'bg-amber-500 animate-pulse' },
  connected: { label: 'Connected', color: 'text-emerald-400', dot: 'bg-emerald-500' },
  failed: { label: 'Failed', color: 'text-red-400', dot: 'bg-red-500' },
};

export function StatusIndicator({ state }: StatusIndicatorProps) {
  const config = STATE_CONFIG[state];
  return (
    <div className="flex items-center gap-2">
      <span className={`w-2.5 h-2.5 rounded-full ${config.dot}`} />
      <span className={`text-sm font-medium ${config.color}`}>{config.label}</span>
    </div>
  );
}

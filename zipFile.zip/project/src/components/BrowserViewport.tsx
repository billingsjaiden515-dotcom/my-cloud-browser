import { useCallback } from 'react';
import type { RemoteBrowserApi, ConnectionState } from '@/hooks/useRemoteBrowser';

interface BrowserViewportProps {
  api: RemoteBrowserApi;
  connectionState: ConnectionState;
  videoRef: React.RefObject<HTMLVideoElement>;
}

const KEY_MAP: Record<string, string> = {
  'Enter': 'Enter',
  'Backspace': 'Backspace',
  'Tab': 'Tab',
  'Escape': 'Escape',
  'ArrowUp': 'ArrowUp',
  'ArrowDown': 'ArrowDown',
  'ArrowLeft': 'ArrowLeft',
  'ArrowRight': 'ArrowRight',
  'Delete': 'Delete',
  'Home': 'Home',
  'End': 'End',
  'PageUp': 'PageUp',
  'PageDown': 'PageDown',
  ' ': 'Space',
};

export function BrowserViewport({ api, connectionState, videoRef }: BrowserViewportProps) {
  const getRelativeCoords = useCallback((e: React.MouseEvent): { x: number; y: number } => {
    const video = videoRef.current;
    if (!video) return { x: 0, y: 0 };

    const rect = video.getBoundingClientRect();
    const scaleX = (video.videoWidth || 1280) / rect.width;
    const scaleY = (video.videoHeight || 800) / rect.height;

    return {
      x: Math.round((e.clientX - rect.left) * scaleX),
      y: Math.round((e.clientY - rect.top) * scaleY),
    };
  }, [videoRef]);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (connectionState !== 'connected') return;
    e.preventDefault();
    const { x, y } = getRelativeCoords(e);
    const button = e.button === 2 ? 'right' : e.button === 1 ? 'middle' : 'left';
    api.sendMouseClick(x, y, button);
  }, [connectionState, getRelativeCoords, api]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (connectionState !== 'connected') return;
    const { x, y } = getRelativeCoords(e);
    api.sendMouseMove(x, y);
  }, [connectionState, getRelativeCoords, api]);

  const handleWheel = useCallback((e: React.WheelEvent) => {
    if (connectionState !== 'connected') return;
    const { x, y } = getRelativeCoords(e);
    api.sendMouseScroll(x, y, -e.deltaX, -e.deltaY);
  }, [connectionState, getRelativeCoords, api]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (connectionState !== 'connected') return;
    const key = KEY_MAP[e.key] || e.key;
    if (key.length === 1 || KEY_MAP[e.key]) {
      e.preventDefault();
    }
    api.sendKeyDown(key);
  }, [connectionState, api]);

  const handleKeyUp = useCallback((e: React.KeyboardEvent) => {
    if (connectionState !== 'connected') return;
    const key = KEY_MAP[e.key] || e.key;
    api.sendKeyUp(key);
  }, [connectionState, api]);

  const handleContextMenu = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
  }, []);

  const isConnected = connectionState === 'connected';

  return (
    <div
      className="relative w-full h-full bg-gray-950 rounded-lg overflow-hidden"
      tabIndex={0}
      onKeyDown={handleKeyDown}
      onKeyUp={handleKeyUp}
    >
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="w-full h-full object-contain cursor-default select-none"
        onMouseDown={handleMouseDown}
        onMouseMove={isConnected ? handleMouseMove : undefined}
        onWheel={handleWheel}
        onContextMenu={handleContextMenu}
      />

      {!isConnected && (
        <div className="absolute inset-0 flex items-center justify-center bg-gray-950/80">
          <div className="text-center">
            {connectionState === 'connecting' && (
              <>
                <div className="inline-block w-10 h-10 border-2 border-sky-500 border-t-transparent rounded-full animate-spin mb-4" />
                <p className="text-gray-400 text-sm">Establishing WebRTC connection...</p>
              </>
            )}
            {connectionState === 'disconnected' && (
              <p className="text-gray-500 text-sm">No active session. Click Start to launch a remote browser.</p>
            )}
            {connectionState === 'failed' && (
              <p className="text-red-400 text-sm">Connection failed. Check error message above.</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

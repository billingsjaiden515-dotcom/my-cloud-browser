import { useCallback, useEffect, useRef, useState } from 'react';
import type { SignalMessage, OfferPayload } from '@/shared/types';

const API_BASE = import.meta.env.VITE_SERVER_URL || 'http://localhost:3001';
const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:3001/signal';

export type ConnectionState =
  | 'disconnected'
  | 'connecting'
  | 'connected'
  | 'failed';

export interface RemoteBrowserApi {
  sessionId: string | null;
  connectionState: ConnectionState;
  error: string | null;
  start: () => Promise<void>;
  stop: () => Promise<void>;
  sendMouseClick: (x: number, y: number, button?: 'left' | 'right' | 'middle') => Promise<void>;
  sendMouseMove: (x: number, y: number) => Promise<void>;
  sendMouseScroll: (x: number, y: number, deltaX: number, deltaY: number) => Promise<void>;
  sendKeyDown: (key: string) => Promise<void>;
  sendKeyUp: (key: string) => Promise<void>;
  sendKeyPress: (key: string) => Promise<void>;
  typeText: (text: string) => Promise<void>;
}

export function useRemoteBrowser(videoRef: React.RefObject<HTMLVideoElement>): RemoteBrowserApi {
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [connectionState, setConnectionState] = useState<ConnectionState>('disconnected');
  const [error, setError] = useState<string | null>(null);

  const pcRef = useRef<RTCPeerConnection | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const sessionIdRef = useRef<string | null>(null);

  const sendSignal = useCallback((msg: SignalMessage) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(msg));
    }
  }, []);

  const setupWebRTC = useCallback((sid: string) => {
    const pc = new RTCPeerConnection();

    pc.onconnectionstatechange = () => {
      const state = pc.connectionState;
      if (state === 'connected') setConnectionState('connected');
      else if (state === 'failed' || state === 'disconnected' || state === 'closed') {
        setConnectionState(state === 'failed' ? 'failed' : 'disconnected');
      }
    };

    pc.ontrack = (event: RTCTrackEvent) => {
      console.log('[Client] Track received:', event.track.kind);
      if (videoRef.current && event.streams[0]) {
        videoRef.current.srcObject = event.streams[0];
        videoRef.current.play().catch((e) => console.error('[Client] Auto-play failed:', e));
      }
    };

    pc.onicecandidate = (event: RTCPeerConnectionIceEvent) => {
      if (event.candidate) {
        sendSignal({
          type: 'ice',
          sessionId: sid,
          payload: { candidate: event.candidate.toJSON() },
        });
      }
    };

    pc.addTransceiver('video', { direction: 'recvonly' });

    pcRef.current = pc;
    return pc;
  }, [videoRef, sendSignal]);

  const start = useCallback(async () => {
    setError(null);
    setConnectionState('connecting');

    try {
      const response = await fetch(`${API_BASE}/api/session/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) {
        const err = await response.json();
        throw new Error(err.message || 'Failed to start session');
      }
      const data = await response.json();
      const sid = data.sessionId as string;
      sessionIdRef.current = sid;
      setSessionId(sid);

      const ws = new WebSocket(WS_URL);
      wsRef.current = ws;

      ws.onopen = async () => {
        console.log('[Client] WebSocket connected, creating WebRTC offer');
        const pc = setupWebRTC(sid);
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);

        sendSignal({
          type: 'offer',
          sessionId: sid,
          payload: { type: 'offer', sdp: offer.sdp } as OfferPayload,
        });
      };

      ws.onmessage = async (event: MessageEvent) => {
        const msg: SignalMessage = JSON.parse(event.data);
        console.log(`[Client] Received signal: ${msg.type}`);

        if (msg.type === 'answer') {
          const payload = msg.payload as OfferPayload;
          const pc = pcRef.current;
          if (pc) {
            await pc.setRemoteDescription(
              new RTCSessionDescription({ type: 'answer', sdp: payload.sdp }),
            );
          }
        } else if (msg.type === 'ice') {
          const payload = msg.payload as { candidate: RTCIceCandidateInit };
          const pc = pcRef.current;
          if (pc && payload.candidate) {
            try {
              await pc.addIceCandidate(payload.candidate);
            } catch (e) {
              console.error('[Client] Failed to add ICE candidate:', e);
            }
          }
        } else if (msg.type === 'error') {
          const payload = msg.payload as { message: string };
          setError(payload.message);
          setConnectionState('failed');
        }
      };

      ws.onerror = () => {
        setError('WebSocket signaling connection failed');
        setConnectionState('failed');
      };

      ws.onclose = () => {
        console.log('[Client] WebSocket closed');
      };
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to start browser session');
      setConnectionState('failed');
    }
  }, [setupWebRTC, sendSignal]);

  const stop = useCallback(async () => {
    const sid = sessionIdRef.current;
    if (sid) {
      try {
        await fetch(`${API_BASE}/api/session/stop`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sessionId: sid }),
        });
      } catch {
        // ignore
      }
    }
    if (pcRef.current) {
      pcRef.current.close();
      pcRef.current = null;
    }
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    sessionIdRef.current = null;
    setSessionId(null);
    setConnectionState('disconnected');
  }, [videoRef]);

  const sendInput = useCallback(async (endpoint: string, body: Record<string, unknown>) => {
    const sid = sessionIdRef.current;
    if (!sid) return;
    try {
      await fetch(`${API_BASE}/api/input/${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId: sid, ...body }),
      });
    } catch (e) {
      console.error(`[Client] Input ${endpoint} failed:`, e);
    }
  }, []);

  const sendMouseClick = useCallback((x: number, y: number, button: 'left' | 'right' | 'middle' = 'left') =>
    sendInput('mouse', { action: 'click', x, y, button }), [sendInput]);

  const sendMouseMove = useCallback((x: number, y: number) =>
    sendInput('mouse', { action: 'move', x, y }), [sendInput]);

  const sendMouseScroll = useCallback((x: number, y: number, deltaX: number, deltaY: number) =>
    sendInput('mouse', { action: 'scroll', x, y, deltaX, deltaY }), [sendInput]);

  const sendKeyDown = useCallback((key: string) =>
    sendInput('keyboard', { action: 'keydown', key }), [sendInput]);

  const sendKeyUp = useCallback((key: string) =>
    sendInput('keyboard', { action: 'keyup', key }), [sendInput]);

  const sendKeyPress = useCallback((key: string) =>
    sendInput('keyboard', { action: 'keypress', key }), [sendInput]);

  const typeText = useCallback((text: string) =>
    sendInput('keyboard', { action: 'type', text }), [sendInput]);

  useEffect(() => {
    return () => {
      if (pcRef.current) pcRef.current.close();
      if (wsRef.current) wsRef.current.close();
    };
  }, []);

  return {
    sessionId,
    connectionState,
    error,
    start,
    stop,
    sendMouseClick,
    sendMouseMove,
    sendMouseScroll,
    sendKeyDown,
    sendKeyUp,
    sendKeyPress,
    typeText,
  };
}

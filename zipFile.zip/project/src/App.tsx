import { useRef, useState } from 'react';
import { Play, Square, Monitor, AlertCircle, X } from 'lucide-react';
import { useRemoteBrowser } from '@/hooks/useRemoteBrowser';
import { BrowserViewport } from '@/components/BrowserViewport';
import { StatusIndicator } from '@/components/StatusIndicator';

export default function App() {
  const [showError, setShowError] = useState(true);
  const videoRef = useRef<HTMLVideoElement>(null);
  const api = useRemoteBrowser(videoRef);
  const { connectionState, error } = api;

  const isBusy = connectionState === 'connecting';
  const isConnected = connectionState === 'connected' || connectionState === 'connecting';

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 flex flex-col">
      {/* Header */}
      <header className="border-b border-gray-800 bg-gray-900/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-sky-500/10 border border-sky-500/30 flex items-center justify-center">
              <Monitor className="w-5 h-5 text-sky-400" />
            </div>
            <div>
              <h1 className="text-lg font-semibold tracking-tight">Cloud Browser</h1>
              <p className="text-xs text-gray-500">Remote Chromium via WebRTC</p>
            </div>
          </div>
          <StatusIndicator state={connectionState} />
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-6 flex flex-col gap-4">
        {/* Error banner */}
        {error && showError && (
          <div className="flex items-start gap-3 bg-red-950/40 border border-red-800/50 rounded-lg px-4 py-3">
            <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-sm text-red-200 font-medium">Connection Error</p>
              <p className="text-sm text-red-300/80 mt-0.5">{error}</p>
            </div>
            <button
              onClick={() => setShowError(false)}
              className="text-red-400 hover:text-red-300 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Toolbar */}
        <div className="flex items-center gap-3">
          <button
            onClick={api.start}
            disabled={isBusy || isConnected}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:bg-gray-700 disabled:text-gray-500 text-white font-medium text-sm transition-colors"
          >
            <Play className="w-4 h-4" />
            Start Browser
          </button>
          <button
            onClick={api.stop}
            disabled={!isConnected}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-red-600/90 hover:bg-red-500 disabled:bg-gray-700 disabled:text-gray-500 text-white font-medium text-sm transition-colors"
          >
            <Square className="w-4 h-4" />
            Stop Browser
          </button>
          {api.sessionId && (
            <span className="text-xs text-gray-500 font-mono ml-2">
              Session: {api.sessionId.slice(0, 8)}...
            </span>
          )}
        </div>

        {/* Viewport */}
        <div className="flex-1 min-h-[500px] rounded-xl border border-gray-800 bg-gray-900 overflow-hidden shadow-2xl">
          <BrowserViewport api={api} connectionState={connectionState} videoRef={videoRef} />
        </div>

        {/* Info footer */}
        <div className="text-xs text-gray-600 flex items-center justify-between">
          <span>Click on the viewport to interact. Keyboard input is captured when the viewport is focused.</span>
          <span className="font-mono">{connectionState}</span>
        </div>
      </main>
    </div>
  );
}

import { RTCPeerConnection, RtpBuilder, RtpPacket, RTCSessionDescription } from 'werift';
import type { BrowserSession } from './browser-session.js';

const CLOCK_RATE = 90000;
const SSRC = Math.floor(Math.random() * 0xffffffff);
const FRAME_INTERVAL_MS = 33;

export class WebRTCStreamer {
  private pc: RTCPeerConnection | null = null;
  private rtpBuilder: RtpBuilder | null = null;
  private sender: { sendRtp: (packet: RtpPacket) => void } | null = null;
  private session: BrowserSession;
  private frameCount = 0;
  private streaming = false;
  private iceCandidateCallback: ((candidate: unknown) => void) | null = null;

  constructor(session: BrowserSession) {
    this.session = session;
  }

  onIceCandidate(callback: (candidate: unknown) => void): void {
    this.iceCandidateCallback = callback;
  }

  async processOffer(offerSdp: string): Promise<string> {
    this.pc = new RTCPeerConnection();

    (this.pc as unknown as { onicecandidate: ((e: { candidate: unknown }) => void) | null }).onicecandidate = (event: { candidate: unknown }) => {
      if (event.candidate && this.iceCandidateCallback) {
        this.iceCandidateCallback(event.candidate);
      }
    };

    this.pc.onconnectionstatechange = () => {
      console.log(`[WebRTC] Connection state: ${this.pc?.connectionState}`);
    };

    this.pc.addTransceiver('video', { direction: 'sendonly' });

    const offer = new RTCSessionDescription(offerSdp, 'offer');
    await this.pc.setRemoteDescription(offer);

    const answer = await this.pc.createAnswer();
    await this.pc.setLocalDescription(answer);

    console.log('[WebRTC] Offer processed, answer created');
    return answer.sdp || '';
  }

  async addIceCandidate(candidate: RTCIceCandidateInit): Promise<void> {
    if (!this.pc) return;
    try {
      await this.pc.addIceCandidate(candidate);
    } catch (e) {
      console.error('[WebRTC] Failed to add ICE candidate:', e);
    }
  }

  startStreaming(): void {
    if (this.streaming) return;

    if (!this.pc) {
      console.error('[WebRTC] Cannot start streaming - no peer connection');
      return;
    }

    const transceivers = this.pc.getTransceivers();
    const videoTransceiver = transceivers.find((t) => t.kind === 'video');
    if (!videoTransceiver) {
      console.error('[WebRTC] No video transceiver found');
      return;
    }

    this.sender = videoTransceiver.sender as unknown as { sendRtp: (packet: RtpPacket) => void };

    this.rtpBuilder = new RtpBuilder({
      between: FRAME_INTERVAL_MS,
      clockRate: CLOCK_RATE,
    } as unknown as ConstructorParameters<typeof RtpBuilder>[0]);

    this.streaming = true;

    this.session.onFrame((jpegBase64: string, width: number, height: number) => {
      if (!this.streaming) return;
      if (this.frameCount === 0) {
        console.log(`[WebRTC] First frame received: ${jpegBase64.length} bytes at ${width}x${height}`);
      }
      this.sendFrame(jpegBase64, width, height);
    });

    console.log('[WebRTC] Streaming started');
  }

  private sendFrame(jpegBase64: string, width: number, height: number): void {
    if (!this.rtpBuilder || !this.sender) return;

    const jpegData = Buffer.from(jpegBase64, 'base64');

    try {
      const packet = this.rtpBuilder.create(jpegData);
      this.sender.sendRtp(packet);
    } catch {
      // Connection might not be ready yet
    }

    this.frameCount++;
    if (this.frameCount % 30 === 0) {
      console.log(`[WebRTC] Sent ${this.frameCount} frames, last frame ${jpegData.length} bytes at ${width}x${height}`);
    }
  }

  async stop(): Promise<void> {
    this.streaming = false;
    if (this.pc) {
      try { this.pc.close(); } catch { /* ignore */ }
      this.pc = null;
    }
    this.rtpBuilder = null;
    this.sender = null;
    console.log('[WebRTC] Streaming stopped');
  }

  isStreaming(): boolean {
    return this.streaming;
  }
}

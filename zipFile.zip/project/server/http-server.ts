import express from 'express';
import cors from 'cors';
import { SessionManager } from './session-manager.js';
import { SignalingServer } from './signaling-server.js';
import http from 'http';

export function createServer(): http.Server {
  const app = express();
  app.use(cors());
  app.use(express.json());

  const sessionManager = new SessionManager();

  app.post('/api/session/start', async (req, res) => {
    try {
      const sessionId = await sessionManager.startSession();
      sessionManager.createStreamer(sessionId);
      res.json({
        sessionId,
        status: 'streaming',
        message: 'Browser session started',
      });
    } catch (e) {
      console.error('[HTTP] Failed to start session:', e);
      res.status(500).json({
        error: 'start_failed',
        message: e instanceof Error ? e.message : 'Unknown error',
      });
    }
  });

  app.post('/api/session/stop', async (req, res) => {
    try {
    const { sessionId } = req.body as { sessionId?: string };
      if (!sessionId) {
        res.status(400).json({ error: 'missing_session', message: 'sessionId required' });
        return;
      }
      await sessionManager.stopSession(sessionId);
      res.json({ status: 'stopped', message: 'Session stopped' });
    } catch (e) {
      console.error('[HTTP] Failed to stop session:', e);
      res.status(500).json({
        error: 'stop_failed',
        message: e instanceof Error ? e.message : 'Unknown error',
      });
    }
  });

  app.get('/api/session/status', async (req, res) => {
    const sessionId = req.query.sessionId as string | undefined;
    if (sessionId) {
      const exists = sessionManager.hasSession(sessionId);
      res.json({ sessionId, active: exists });
    } else {
      const ids = sessionManager.getActiveSessionIds();
      res.json({ activeSessions: ids, count: ids.length });
    }
  });

  app.post('/api/input/mouse', async (req, res) => {
    try {
      const { sessionId, action, x, y, button, deltaX, deltaY } = req.body as {
        sessionId: string;
        action: 'click' | 'move' | 'scroll';
        x: number;
        y: number;
        button?: 'left' | 'right' | 'middle';
        deltaX?: number;
        deltaY?: number;
      };
      const browser = sessionManager.getBrowser(sessionId);
      if (!browser) {
        res.status(404).json({ error: 'session_not_found', message: 'Session not found' });
        return;
      }
      switch (action) {
        case 'click':
          await browser.sendMouseClick(x, y, button || 'left');
          break;
        case 'move':
          await browser.sendMouseMove(x, y);
          break;
        case 'scroll':
          await browser.sendMouseScroll(deltaX || 0, deltaY || 0, x, y);
          break;
      }
      res.json({ ok: true });
    } catch (e) {
      res.status(500).json({
        error: 'input_failed',
        message: e instanceof Error ? e.message : 'Unknown error',
      });
    }
  });

  app.post('/api/input/keyboard', async (req, res) => {
    try {
      const { sessionId, action, key, text } = req.body as {
        sessionId: string;
        action: 'keydown' | 'keyup' | 'keypress' | 'type';
        key?: string;
        text?: string;
      };
      const browser = sessionManager.getBrowser(sessionId);
      if (!browser) {
        res.status(404).json({ error: 'session_not_found', message: 'Session not found' });
        return;
      }
      switch (action) {
        case 'keydown':
          if (key) await browser.sendKeyDown(key);
          break;
        case 'keyup':
          if (key) await browser.sendKeyUp(key);
          break;
        case 'keypress':
          if (key) await browser.sendKeyPress(key);
          break;
        case 'type':
          if (text) await browser.typeText(text);
          break;
      }
      res.json({ ok: true });
    } catch (e) {
      res.status(500).json({
        error: 'input_failed',
        message: e instanceof Error ? e.message : 'Unknown error',
      });
    }
  });

  const server = http.createServer(app);
  const signaling = new SignalingServer(server, sessionManager);

  server.on('close', async () => {
    await sessionManager.stopAll();
    signaling.close();
  });

  return server;
}

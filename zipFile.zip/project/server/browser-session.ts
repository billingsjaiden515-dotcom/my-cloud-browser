import puppeteer, { Browser, Page, CDPSession } from 'puppeteer-core';

const CHROMIUM_PATH = '/usr/bin/chromium';
const VIEWPORT_WIDTH = 1280;
const VIEWPORT_HEIGHT = 800;
const FRAME_RATE = 30;

export interface FrameCallback {
  (jpegBase64: string, width: number, height: number): void;
}

export class BrowserSession {
  sessionId: string;
  private browser: Browser | null = null;
  private page: Page | null = null;
  private screencastActive = false;
  private frameCallback: FrameCallback | null = null;
  private cdpSession: CDPSession | null = null;

  constructor(sessionId: string) {
    this.sessionId = sessionId;
  }

  async launch(): Promise<void> {
    this.browser = await puppeteer.launch({
      executablePath: CHROMIUM_PATH,
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-gpu',
        '--disable-dev-shm-usage',
        '--disable-software-rasterizer',
        '--no-first-run',
        '--no-default-browser-check',
        '--disable-extensions',
        '--disable-background-networking',
        '--disable-sync',
        '--disable-translate',
        '--metrics-recording-only',
        '--mute-audio',
        `--window-size=${VIEWPORT_WIDTH},${VIEWPORT_HEIGHT}`,
      ],
    });

    const pages = await this.browser.pages();
    this.page = pages[0] || (await this.browser.newPage());
    await this.page.setViewport({
      width: VIEWPORT_WIDTH,
      height: VIEWPORT_HEIGHT,
      deviceScaleFactor: 1,
    });

    await this.page.goto('https://www.wikipedia.org', {
      waitUntil: 'domcontentloaded',
      timeout: 20000,
    }).catch(() => {
      // If network fails, navigate to about:blank
    });

    await this.page.addStyleTag({
      content: `
        @keyframes force-redraw {
          0% { opacity: 0.999; }
          50% { opacity: 1; }
          100% { opacity: 0.999; }
        }
        body { animation: force-redraw 1s infinite; }
      `,
    }).catch(() => {});
  }

  onFrame(callback: FrameCallback): void {
    this.frameCallback = callback;
  }

  async startScreencast(): Promise<void> {
    if (!this.page) throw new Error('Page not initialized');
    if (this.screencastActive) return;

    this.cdpSession = await this.page.target().createCDPSession();

    this.cdpSession.on('Page.screencastFrame', (payload: {
      data: string;
      sessionId: number;
      metadata: { deviceWidth: number; deviceHeight: number };
    }) => {
      if (this.frameCallback) {
        this.frameCallback(
          payload.data,
          payload.metadata?.deviceWidth || VIEWPORT_WIDTH,
          payload.metadata?.deviceHeight || VIEWPORT_HEIGHT,
        );
      }
      this.cdpSession?.send('Page.screencastFrameAck', {
        sessionId: payload.sessionId,
      }).catch(() => {});
    });

    await this.cdpSession.send('Page.startScreencast', {
      format: 'jpeg',
      quality: 70,
      everyNthFrame: 1,
      maxWidth: VIEWPORT_WIDTH,
      maxHeight: VIEWPORT_HEIGHT,
    });

    this.screencastActive = true;
  }

  async stopScreencast(): Promise<void> {
    if (!this.screencastActive || !this.cdpSession) return;
    try {
      await this.cdpSession.send('Page.stopScreencast');
    } catch {
      // ignore
    }
    this.screencastActive = false;
  }

  getViewport(): { width: number; height: number } {
    return { width: VIEWPORT_WIDTH, height: VIEWPORT_HEIGHT };
  }

  async sendMouseClick(x: number, y: number, button: 'left' | 'right' | 'middle' = 'left'): Promise<void> {
    if (!this.page) return;
    await this.page.mouse.click(x, y, { button });
  }

  async sendMouseMove(x: number, y: number): Promise<void> {
    if (!this.page) return;
    await this.page.mouse.move(x, y);
  }

  async sendMouseScroll(deltaX: number, deltaY: number, x: number, y: number): Promise<void> {
    if (!this.page) return;
    await this.page.mouse.move(x, y);
    await this.page.mouse.wheel({ deltaX, deltaY });
  }

  async sendKeyDown(key: string): Promise<void> {
    if (!this.page) return;
    await this.page.keyboard.down(key as import('puppeteer-core').KeyInput);
  }

  async sendKeyUp(key: string): Promise<void> {
    if (!this.page) return;
    await this.page.keyboard.up(key as import('puppeteer-core').KeyInput);
  }

  async sendKeyPress(key: string): Promise<void> {
    if (!this.page) return;
    await this.page.keyboard.press(key as import('puppeteer-core').KeyInput);
  }

  async typeText(text: string): Promise<void> {
    if (!this.page) return;
    await this.page.keyboard.type(text, { delay: 30 });
  }

  async navigate(url: string): Promise<void> {
    if (!this.page) return;
    await this.page.goto(url, { waitUntil: 'domcontentloaded', timeout: 20000 }).catch(() => {});
  }

  async stop(): Promise<void> {
    await this.stopScreencast();
    if (this.cdpSession) {
      try { await this.cdpSession.detach(); } catch { /* ignore */ }
      this.cdpSession = null;
    }
    if (this.browser) {
      try { await this.browser.close(); } catch { /* ignore */ }
      this.browser = null;
    }
    this.page = null;
    this.frameCallback = null;
  }
}

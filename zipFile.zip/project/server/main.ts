import { createServer } from './http-server.js';

const PORT = parseInt(process.env.SERVER_PORT || '3001', 10);

const server = createServer();

server.listen(PORT, () => {
  console.log(`[Server] Remote browser server listening on port ${PORT}`);
  console.log(`[Server] HTTP API: http://localhost:${PORT}/api`);
  console.log(`[Server] WebSocket signaling: ws://localhost:${PORT}/signal`);
});

const cleanup = async () => {
  console.log('[Server] Shutting down...');
  server.close();
  process.exit(0);
};

process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);
